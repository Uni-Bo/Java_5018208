package springfox.documentation.builders;

public class PathSelectors {
	public static Object any() {
		return null;
	}
}
